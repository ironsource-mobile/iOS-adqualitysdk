//
//  ISAdQualityWKWebViewManager.h
//  ironSource Ad Quality
//
//  Created by refael dakar on 5/4/16.
//  Copyright © 2016 SOOMLA. All rights reserved.
//

#import <WebKit/WebKit.h>
#import "ISAdQualityWebViewNavigationType.h"

@protocol WKWebViewListener <NSObject>

@property(nonatomic, strong) NSString *urlPrefix;

@optional
- (void)webView:(WKWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request;
- (void)webView:(WKWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(ISAdQualityWebViewNavigationType)navigationType;

@end

@interface ISAdQualityWKWebViewManager : NSObject

+ (void)adQualityInitialize;

+ (void)addListener:(id<WKWebViewListener>) listener;
+ (void)addListener:(id<WKWebViewListener>) listener forWebView:(WKWebView *)webView;
+ (void)removeListener:(id<WKWebViewListener>) listener;
+ (void)removeWebViewListener:(id<WKWebViewListener>) listener;
+ (void)webView:(WKWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(ISAdQualityWebViewNavigationType)navigationType;

@end
