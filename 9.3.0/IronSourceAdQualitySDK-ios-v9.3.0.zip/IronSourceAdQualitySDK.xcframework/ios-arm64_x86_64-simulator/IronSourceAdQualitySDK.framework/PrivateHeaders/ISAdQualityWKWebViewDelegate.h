//
//  ISAdQualityWKWebViewDelegate.h
//
//  Created by refael dakar on 4/21/16.
//  Copyright © 2016 SOOMLA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>

@interface ISAdQualityWKWebViewDelegate : NSObject<WKNavigationDelegate>

@property (nonatomic, weak) id<WKNavigationDelegate> delegate;

@property (nonatomic) id<WKNavigationDelegate> strongDelegate;

@end
