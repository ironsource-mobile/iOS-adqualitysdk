/*
 * Copyright (C) 2012-2016 Soomla Inc. - All Rights Reserved
 *
 *   Unauthorized copying of this file, via any medium is strictly prohibited
 *   Proprietary and confidential
 *
 *   Written by Refael Dakar <refael@soom.la>
 */

#import <Foundation/Foundation.h>
#import "ISAdQualityAdType.h"
#import "ISAdQualityConfig.h"

#define IRONSOURCE_AD_QUALITY_VERSION    @"6.8.8"

static NSString *IRONSOURCE_AD_QUALITY_TAG = @"ISAdQualitySDK";

@protocol ISAdQualityDelegate <NSObject>

@required

@optional

- (void)adDisplayedForAdNetwork:(NSString *)adNetwork andAdType:(ISAdQualityAdType)adType;
- (void)adClosedForAdNetwork:(NSString *)adNetwork andAdType:(ISAdQualityAdType)adType;

@end

@interface IronSourceAdQuality : NSObject

@property (nonatomic, weak) id<ISAdQualityDelegate> delegate;

+ (IronSourceAdQuality *)getInstance;

- (void)initializeWithAppKey:(NSString *)appKey;
- (void)initializeWithAppKey:(NSString *)appKey andConfig:(ISAdQualityConfig *)config;
- (void)setUserConsent:(BOOL)userConsent;
- (void)shutdown;
- (void)changeUserId:(NSString *)userId;
- (void)addExtraUserId:(NSString *)userId;

@end
